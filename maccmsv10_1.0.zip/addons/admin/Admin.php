<?php
/**
Admin采集插件：https://www.admincj.com
**/
namespace addons\admin;use think\Addons;class admin extends Addons{public function install(){return true;}public function uninstall(){return true;}}